var searchData=
[
  ['os_5ftimer_5ftype',['os_timer_type',['../group___c_m_s_i_s___r_t_o_s___timer_mgmt.html#gadac860eb9e1b4b0619271e6595ed83d9',1,'os_timer_type():&#160;cmsis_os.txt'],['../cmsis__os_8h.html#adac860eb9e1b4b0619271e6595ed83d9',1,'os_timer_type():&#160;cmsis_os.h']]],
  ['ospriority',['osPriority',['../group___c_m_s_i_s___r_t_o_s___thread_mgmt.html#ga7f2b42f1983b9107775ec2a1c69a849a',1,'osPriority():&#160;cmsis_os.txt'],['../cmsis__os_8h.html#a7f2b42f1983b9107775ec2a1c69a849a',1,'osPriority():&#160;cmsis_os.h']]],
  ['osstatus',['osStatus',['../group___c_m_s_i_s___r_t_o_s___status.html#gae2e091fefc4c767117727bd5aba4d99e',1,'osStatus():&#160;cmsis_os.txt'],['../cmsis__os_8h.html#ae2e091fefc4c767117727bd5aba4d99e',1,'osStatus():&#160;cmsis_os.h']]]
];
